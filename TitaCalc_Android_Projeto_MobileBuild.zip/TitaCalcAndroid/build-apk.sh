#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$ANDROID_SDK_ROOT" ]]; then
  echo "Android SDK não encontrado. Instale o Android Studio e o SDK Platform 35 pelo SDK Manager." >&2
  exit 1
fi
if command -v gradle >/dev/null 2>&1; then
  GRADLE=gradle
else
  VERSION=8.9
  TOOL_DIR="$(pwd)/.tools"
  GRADLE_HOME="$TOOL_DIR/gradle-$VERSION"
  if [[ ! -x "$GRADLE_HOME/bin/gradle" ]]; then
    mkdir -p "$TOOL_DIR"
    echo "Baixando Gradle $VERSION para a primeira compilação..."
    curl -fL "https://services.gradle.org/distributions/gradle-$VERSION-bin.zip" -o "$TOOL_DIR/gradle.zip"
    unzip -oq "$TOOL_DIR/gradle.zip" -d "$TOOL_DIR"
    rm -f "$TOOL_DIR/gradle.zip"
  fi
  GRADLE="$GRADLE_HOME/bin/gradle"
fi
"$GRADLE" --no-daemon assembleDebug
echo "APK criado em: app/build/outputs/apk/debug/app-debug.apk"
