# Titã Calc — Projeto Android

Este projeto empacota o HTML original enviado (`TITÃCALC.html`) em um aplicativo Android nativo com WebView local. A interface, regras e recursos do HTML são mantidos; o projeto acrescenta a integração Android para escolher arquivos de imagem/importação e salvar o backup JSON pelo seletor de documentos do Android.

## Armazenamento dos dados

O HTML continua usando IndexedDB (`TitaCalcLocalDB`) e `localStorage` como alternativa. O WebView serve o HTML por uma origem HTTPS interna estável (`https://appassets.androidplatform.net/index.html`), para que IndexedDB e localStorage persistam dentro dos dados privados do aplicativo. Os dados permanecem entre aberturas e atualizações do app com o mesmo `applicationId` e assinatura.

A desinstalação ou a opção Android **Configurações > Aplicativos > Titã Calc > Armazenamento > Limpar dados** apaga os dados locais. Use **Exportar arquivo** para manter um backup.

## Requisitos para gerar o APK

- Android Studio instalado em um computador.
- Android SDK Platform 35 e Android Build Tools instalados pelo SDK Manager.
- JDK 17 ou superior (o Android Studio inclui um JBR compatível).
- Acesso à internet na primeira compilação para baixar o Android Gradle Plugin 8.7.3 e Gradle 8.9. O script de terminal baixa o Gradle 8.9 automaticamente se ele não estiver instalado.

## Gerar o APK no Android Studio

1. Extraia a pasta `TitaCalcAndroid`.
2. Abra o Android Studio e escolha **Open**; selecione a pasta `TitaCalcAndroid` (a pasta que contém `settings.gradle`).
3. Aguarde o Gradle Sync e aceite instalar o SDK Platform 35/Build Tools se o Android Studio solicitar.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de teste ficará em `app/build/outputs/apk/debug/app-debug.apk`.
6. Copie o APK para o Android, abra-o e permita a instalação desta origem quando solicitado.

O APK `debug` é assinado automaticamente para instalação e testes. Para publicação na Play Store ou distribuição profissional, crie uma assinatura `release` própria no Android Studio.

## Gerar pelo terminal

Com Android SDK Platform 35 instalado e `ANDROID_SDK_ROOT` apontando para o SDK:

- Windows: execute `build-apk.bat` (baixa Gradle 8.9 automaticamente se necessário).
- Linux/macOS: execute `./build-apk.sh` (baixa Gradle 8.9 automaticamente se necessário).

## Pacote e permissões

- Application ID: `com.jornadadotita.titacalc`
- Versão inicial: `1.0.0` (`versionCode 1`)
- Android mínimo: 6.0 (API 23)
- Orientação: retrato
- Não solicita permissão ampla para fotos/arquivos. O seletor de documentos do Android dá acesso somente aos arquivos que a pessoa selecionar.
- A permissão de Internet é declarada para o carregamento local HTTPS do WebView; o HTML e as imagens ficam no APK e não dependem de um servidor externo.
