@echo off
setlocal
set "PROJECT_DIR=%~dp0"
set "GRADLE_VERSION=8.9"
if "%ANDROID_SDK_ROOT%"=="" if not "%ANDROID_HOME%"=="" set "ANDROID_SDK_ROOT=%ANDROID_HOME%"
if "%ANDROID_SDK_ROOT%"=="" if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_SDK_ROOT=%LOCALAPPDATA%\Android\Sdk"
if "%ANDROID_SDK_ROOT%"=="" (
  echo Android SDK nao encontrado. Instale o Android Studio e o SDK Platform 35 pelo SDK Manager.
  exit /b 1
)
where gradle >nul 2>nul
if errorlevel 1 (
  set "GRADLE_HOME=%PROJECT_DIR%.tools\gradle-%GRADLE_VERSION%"
  if not exist "%PROJECT_DIR%.tools\gradle-%GRADLE_VERSION%\bin\gradle.bat" (
    echo Baixando Gradle %GRADLE_VERSION% para a primeira compilacao...
    if not exist "%PROJECT_DIR%.tools" mkdir "%PROJECT_DIR%.tools"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%PROJECT_DIR%.tools\gradle.zip'; Expand-Archive -Force '%PROJECT_DIR%.tools\gradle.zip' '%PROJECT_DIR%.tools'; Remove-Item '%PROJECT_DIR%.tools\gradle.zip'"
    if errorlevel 1 (
      echo Falha ao baixar Gradle. Instale Gradle 8.9 ou abra o projeto pelo Android Studio.
      exit /b 1
    )
  )
  set "GRADLE_CMD=%PROJECT_DIR%.tools\gradle-%GRADLE_VERSION%\bin\gradle.bat"
) else (
  set "GRADLE_CMD=gradle"
)
cd /d "%PROJECT_DIR%"
call %GRADLE_CMD% --no-daemon assembleDebug
if errorlevel 1 exit /b 1
echo.
echo APK criado em: %PROJECT_DIR%app\build\outputs\apk\debug\app-debug.apk
