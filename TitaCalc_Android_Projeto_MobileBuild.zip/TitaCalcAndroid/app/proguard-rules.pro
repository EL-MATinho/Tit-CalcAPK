# The WebView bridge is intentionally retained in release builds.
-keepclassmembers class com.jornadadotita.titacalc.MainActivity$NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
