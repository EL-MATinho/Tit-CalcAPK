package com.jornadadotita.titacalc;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQUEST_FILE_CHOOSER = 4101;
    private static final int REQUEST_CREATE_BACKUP = 4102;
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_URL = "https://" + APP_HOST + "/index.html";

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingExportJson;
    private String pendingExportName = "tita-calc-backup.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(25, 11, 17));
        window.setNavigationBarColor(Color.rgb(25, 11, 17));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setNavigationBarDividerColor(Color.rgb(65, 27, 42));
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(24, 13, 19));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setSaveEnabled(true);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.addJavascriptInterface(new NativeBridge(), "TitaNative");
        webView.setWebViewClient(new LocalAppWebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    Intent chooserIntent = params.createIntent();
                    startActivityForResult(chooserIntent, REQUEST_FILE_CHOOSER);
                    return true;
                } catch (Exception error) {
                    filePathCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this,
                            "Não foi possível abrir os arquivos deste dispositivo.",
                            Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });

        setContentView(webView);
        webView.loadUrl(APP_URL);
    }

    /** Serve o HTML local por uma origem HTTPS estável para IndexedDB/localStorage. */
    private final class LocalAppWebViewClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (APP_HOST.equals(uri.getHost()) &&
                    ("/index.html".equals(uri.getPath()) || "/".equals(uri.getPath()))) {
                try {
                    InputStream html = getAssets().open("index.html");
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Cache-Control", "no-store");
                    headers.put("Access-Control-Allow-Origin", "*");
                    return new WebResourceResponse("text/html", "UTF-8", 200,
                            "OK", headers, html);
                } catch (IOException ignored) {
                    return errorResponse(404, "Not Found");
                }
            }
            if (APP_HOST.equals(uri.getHost())) {
                return errorResponse(404, "Not Found");
            }
            return errorResponse(403, "Forbidden");
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            return !APP_HOST.equals(uri.getHost()) ||
                    !"https".equalsIgnoreCase(uri.getScheme());
        }

        private WebResourceResponse errorResponse(int code, String message) {
            byte[] body = message.getBytes(StandardCharsets.UTF_8);
            return new WebResourceResponse("text/plain", "UTF-8", code,
                    message, Collections.<String, String>emptyMap(),
                    new java.io.ByteArrayInputStream(body));
        }
    }

    /** Ponte nativa mínima: permite salvar backup via seletor de documentos do Android. */
    private final class NativeBridge {
        @JavascriptInterface
        public void saveBackupFile(String json, String filename) {
            if (json == null || json.length() > 40_000_000) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "O arquivo de backup é inválido ou muito grande.", Toast.LENGTH_LONG).show());
                return;
            }
            runOnUiThread(() -> beginSaveBackup(json, filename));
        }
    }

    private void beginSaveBackup(String json, String filename) {
        pendingExportJson = json;
        String safeName = filename == null ? "tita-calc-backup.json" :
                filename.replaceAll("[^A-Za-z0-9._-]", "_");
        if (!safeName.toLowerCase().endsWith(".json")) safeName += ".json";
        pendingExportName = safeName;

        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, pendingExportName);
        try {
            startActivityForResult(intent, REQUEST_CREATE_BACKUP);
        } catch (Exception error) {
            pendingExportJson = null;
            Toast.makeText(this, "Não foi possível abrir o seletor para salvar o backup.",
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_FILE_CHOOSER) {
            if (filePathCallback != null) {
                Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }
        if (requestCode == REQUEST_CREATE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null &&
                    pendingExportJson != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData(), "w")) {
                    if (output == null) throw new IOException("Não foi possível abrir o destino.");
                    output.write(pendingExportJson.getBytes(StandardCharsets.UTF_8));
                    output.flush();
                    Toast.makeText(this, "Backup do Titã Calc salvo.", Toast.LENGTH_LONG).show();
                    updateBackupStatus("Backup salvo com sucesso. Você já pode compartilhar o arquivo .json.");
                } catch (Exception error) {
                    Toast.makeText(this, "Falha ao salvar o backup. Tente outro local.",
                            Toast.LENGTH_LONG).show();
                    updateBackupStatus("Não foi possível salvar o backup neste local.");
                }
            } else {
                updateBackupStatus("Exportação cancelada.");
            }
            pendingExportJson = null;
        }
    }

    private void updateBackupStatus(String message) {
        if (webView == null) return;
        String escaped = message.replace("\\", "\\\\").replace("'", "\\'");
        webView.evaluateJavascript(
                "(function(){var e=document.getElementById('backupStatus');if(e)e.textContent='" +
                        escaped + "';})();", null);
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.evaluateJavascript(
                    "try{if(typeof persistState==='function'){persistState();}}catch(e){}", null);
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            webView.evaluateJavascript(
                    "try{if(typeof persistState==='function'){persistState();}}catch(e){}", null);
            webView.removeJavascriptInterface("TitaNative");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
